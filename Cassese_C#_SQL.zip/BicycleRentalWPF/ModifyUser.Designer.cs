﻿namespace BicycleRentalWPF
{
    partial class ModifyUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.submit_banner = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.banner_id_text_box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(100, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Modify A User";
            // 
            // submit_banner
            // 
            this.submit_banner.Location = new System.Drawing.Point(25, 183);
            this.submit_banner.Name = "submit_banner";
            this.submit_banner.Size = new System.Drawing.Size(107, 22);
            this.submit_banner.TabIndex = 1;
            this.submit_banner.Text = "Submit Banner ID";
            this.submit_banner.UseVisualStyleBackColor = true;
            this.submit_banner.Click += new System.EventHandler(this.submit_button_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(138, 183);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(107, 23);
            this.cancel.TabIndex = 2;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Insert a Banner ID";
            // 
            // banner_id_text_box
            // 
            this.banner_id_text_box.Location = new System.Drawing.Point(138, 65);
            this.banner_id_text_box.Name = "banner_id_text_box";
            this.banner_id_text_box.Size = new System.Drawing.Size(100, 20);
            this.banner_id_text_box.TabIndex = 4;
            // 
            // ModifyUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.banner_id_text_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.submit_banner);
            this.Controls.Add(this.label1);
            this.Name = "ModifyUser";
            this.Text = "ModifyUser";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button submit_banner;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox banner_id_text_box;
    }
}
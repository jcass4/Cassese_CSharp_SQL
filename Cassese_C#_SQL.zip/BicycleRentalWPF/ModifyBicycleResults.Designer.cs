﻿namespace BicycleRentalWPF
{
    partial class ModifyBicycleResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.EnterNewUserDataLabel = new System.Windows.Forms.Label();
            this.PhysicalConditionComboBox = new System.Windows.Forms.ComboBox();
            this.LocationComboBox = new System.Windows.Forms.ComboBox();
            this.ModelNumTextBox = new System.Windows.Forms.TextBox();
            this.NotesTextBox = new System.Windows.Forms.TextBox();
            this.DescriptionTextBox = new System.Windows.Forms.TextBox();
            this.ColorTextBox = new System.Windows.Forms.TextBox();
            this.SerialNumTextBox = new System.Windows.Forms.TextBox();
            this.BikeMakeTextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(229, 329);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(99, 31);
            this.BackButton.TabIndex = 54;
            this.BackButton.Text = "BACK";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(51, 329);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(99, 31);
            this.SubmitButton.TabIndex = 53;
            this.SubmitButton.Text = "SUBMIT";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // EnterNewUserDataLabel
            // 
            this.EnterNewUserDataLabel.AutoSize = true;
            this.EnterNewUserDataLabel.Location = new System.Drawing.Point(128, 19);
            this.EnterNewUserDataLabel.Name = "EnterNewUserDataLabel";
            this.EnterNewUserDataLabel.Size = new System.Drawing.Size(82, 13);
            this.EnterNewUserDataLabel.TabIndex = 39;
            this.EnterNewUserDataLabel.Text = "Enter Bike Data";
            // 
            // PhysicalConditionComboBox
            // 
            this.PhysicalConditionComboBox.FormattingEnabled = true;
            this.PhysicalConditionComboBox.Items.AddRange(new object[] {
            "Good",
            "Damaged"});
            this.PhysicalConditionComboBox.Location = new System.Drawing.Point(211, 245);
            this.PhysicalConditionComboBox.Name = "PhysicalConditionComboBox";
            this.PhysicalConditionComboBox.Size = new System.Drawing.Size(100, 21);
            this.PhysicalConditionComboBox.TabIndex = 70;
            this.PhysicalConditionComboBox.Text = "Select One";
            // 
            // LocationComboBox
            // 
            this.LocationComboBox.FormattingEnabled = true;
            this.LocationComboBox.Items.AddRange(new object[] {
            "Benedict",
            "Brockway",
            "Harmon",
            "McFarlane",
            "Mortimer",
            "Seymour College Union",
            "Thompson",
            "Townhomes",
            "Tuttle",
            "Welcome Center"});
            this.LocationComboBox.Location = new System.Drawing.Point(212, 218);
            this.LocationComboBox.Name = "LocationComboBox";
            this.LocationComboBox.Size = new System.Drawing.Size(100, 21);
            this.LocationComboBox.TabIndex = 69;
            this.LocationComboBox.Text = "Select One";
            // 
            // ModelNumTextBox
            // 
            this.ModelNumTextBox.Location = new System.Drawing.Point(212, 115);
            this.ModelNumTextBox.Name = "ModelNumTextBox";
            this.ModelNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.ModelNumTextBox.TabIndex = 68;
            // 
            // NotesTextBox
            // 
            this.NotesTextBox.Location = new System.Drawing.Point(211, 272);
            this.NotesTextBox.Name = "NotesTextBox";
            this.NotesTextBox.Size = new System.Drawing.Size(100, 20);
            this.NotesTextBox.TabIndex = 67;
            // 
            // DescriptionTextBox
            // 
            this.DescriptionTextBox.Location = new System.Drawing.Point(212, 193);
            this.DescriptionTextBox.Name = "DescriptionTextBox";
            this.DescriptionTextBox.Size = new System.Drawing.Size(100, 20);
            this.DescriptionTextBox.TabIndex = 66;
            // 
            // ColorTextBox
            // 
            this.ColorTextBox.Location = new System.Drawing.Point(212, 167);
            this.ColorTextBox.Name = "ColorTextBox";
            this.ColorTextBox.Size = new System.Drawing.Size(100, 20);
            this.ColorTextBox.TabIndex = 65;
            // 
            // SerialNumTextBox
            // 
            this.SerialNumTextBox.Location = new System.Drawing.Point(212, 141);
            this.SerialNumTextBox.Name = "SerialNumTextBox";
            this.SerialNumTextBox.Size = new System.Drawing.Size(100, 20);
            this.SerialNumTextBox.TabIndex = 64;
            // 
            // BikeMakeTextBox
            // 
            this.BikeMakeTextBox.Location = new System.Drawing.Point(212, 89);
            this.BikeMakeTextBox.Name = "BikeMakeTextBox";
            this.BikeMakeTextBox.Size = new System.Drawing.Size(100, 20);
            this.BikeMakeTextBox.TabIndex = 63;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(67, 118);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 13);
            this.label10.TabIndex = 62;
            this.label10.Text = "Model Number: ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(65, 275);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 61;
            this.label9.Text = "Notes:  ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 13);
            this.label7.TabIndex = 60;
            this.label7.Text = "Phyisical Condition: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(67, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 59;
            this.label6.Text = "Locaiton: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(66, 171);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 58;
            this.label5.Text = "Color: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 57;
            this.label4.Text = "Description: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 13);
            this.label3.TabIndex = 56;
            this.label3.Text = "Serial Number: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 55;
            this.label2.Text = "Bike Make: ";
            // 
            // ModifyBicycleResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 381);
            this.Controls.Add(this.PhysicalConditionComboBox);
            this.Controls.Add(this.LocationComboBox);
            this.Controls.Add(this.ModelNumTextBox);
            this.Controls.Add(this.NotesTextBox);
            this.Controls.Add(this.DescriptionTextBox);
            this.Controls.Add(this.ColorTextBox);
            this.Controls.Add(this.SerialNumTextBox);
            this.Controls.Add(this.BikeMakeTextBox);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.EnterNewUserDataLabel);
            this.Name = "ModifyBicycleResults";
            this.Text = "ModifyBicycleResults";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.Label EnterNewUserDataLabel;
        private System.Windows.Forms.ComboBox PhysicalConditionComboBox;
        private System.Windows.Forms.ComboBox LocationComboBox;
        private System.Windows.Forms.TextBox ModelNumTextBox;
        private System.Windows.Forms.TextBox NotesTextBox;
        private System.Windows.Forms.TextBox DescriptionTextBox;
        private System.Windows.Forms.TextBox ColorTextBox;
        private System.Windows.Forms.TextBox SerialNumTextBox;
        private System.Windows.Forms.TextBox BikeMakeTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class DeleteBicycle : Form
    {
        Form myCaller;

        public DeleteBicycle(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void delete_vehicle_Click(object sender, EventArgs e)
        {
            int bicycleID = Convert.ToInt32(id_text_box.Text);
            Vehicle bicycleToDelete = new Vehicle();
            bicycleToDelete.populate(bicycleID);
            DialogResult result = MessageBox.Show("Are you sure you want to delete this worker?" +
                bicycleToDelete.ModelNumber + "\n" +
                bicycleToDelete.SerialNumber + "\n" +
                bicycleToDelete.PhysicalCondition + "\n" +
                bicycleToDelete.Notes + "\n",
                "Delete Confirm",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                bicycleToDelete.delete();
                MessageBox.Show("You have deleted " + bicycleID);
            }
            else
            {
                id_text_box.Text = "";
            }
            bicycleToDelete.delete();  
        }

        private void cancel_delete_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}

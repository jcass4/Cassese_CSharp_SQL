﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ReturnBike : Form
    {
        Form myCaller;
        Worker myLoggedInWorker;

        public ReturnBike(Form f, Worker w)
        {
            InitializeComponent();
            myCaller = f;
            myLoggedInWorker = w;

            RentalCollection rC = new RentalCollection();
            rC.populateWithRentedOutBikes();

            Object[] rentCol = rC.ToArray();
            BikeSelectionComboBox.Items.AddRange(rentCol);
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string return_ID = BikeSelectionComboBox.Text;

        }

        private void BikeSelectionComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class DeleteUser : Form
    {

        Form myCaller;

        public DeleteUser(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void DeleteUser_Load(object sender, EventArgs e)
        {
            
        }

        private void delete_button_Click(object sender, EventArgs e)
        {
            string bannerIDValue = banner_id_text_box.Text;
            User userToDelete = new User();
            userToDelete.populateWithBannerId(bannerIDValue);
            DialogResult result = MessageBox.Show("Are you sure you want to delete this worker?" +
                userToDelete.BannerId + "\n" +
                userToDelete.FirstName + "\n" +
                userToDelete.LastName + "\n" +
                userToDelete.PhoneNumber + "\n" +
                userToDelete.EmailAddress + "\n" +
                userToDelete.Status,
                "Delete Confirm",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                userToDelete.delete();
                MessageBox.Show("You have deleted " + bannerIDValue);
            }
            else
            {
                banner_id_text_box.Text = "";
            }
        }

        private void back_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }


    }
}

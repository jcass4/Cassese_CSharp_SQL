﻿namespace BicycleRentalWPF
{
    partial class DeleteBicycle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.delete_vehicle = new System.Windows.Forms.Button();
            this.cancel_delete = new System.Windows.Forms.Button();
            this.ID = new System.Windows.Forms.Label();
            this.id_text_box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label1.Location = new System.Drawing.Point(114, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delete Vehicle";
            // 
            // delete_vehicle
            // 
            this.delete_vehicle.Location = new System.Drawing.Point(79, 234);
            this.delete_vehicle.Name = "delete_vehicle";
            this.delete_vehicle.Size = new System.Drawing.Size(98, 38);
            this.delete_vehicle.TabIndex = 1;
            this.delete_vehicle.Text = "Delete";
            this.delete_vehicle.UseVisualStyleBackColor = true;
            this.delete_vehicle.Click += new System.EventHandler(this.delete_vehicle_Click);
            // 
            // cancel_delete
            // 
            this.cancel_delete.Location = new System.Drawing.Point(183, 234);
            this.cancel_delete.Name = "cancel_delete";
            this.cancel_delete.Size = new System.Drawing.Size(98, 38);
            this.cancel_delete.TabIndex = 2;
            this.cancel_delete.Text = "Cancel";
            this.cancel_delete.UseVisualStyleBackColor = true;
            this.cancel_delete.Click += new System.EventHandler(this.cancel_delete_Click);
            // 
            // ID
            // 
            this.ID.AutoSize = true;
            this.ID.Location = new System.Drawing.Point(107, 87);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(18, 13);
            this.ID.TabIndex = 3;
            this.ID.Text = "ID";
            // 
            // id_text_box
            // 
            this.id_text_box.Location = new System.Drawing.Point(131, 84);
            this.id_text_box.Name = "id_text_box";
            this.id_text_box.Size = new System.Drawing.Size(100, 20);
            this.id_text_box.TabIndex = 5;
            // 
            // DeleteBicycle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 323);
            this.Controls.Add(this.id_text_box);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.cancel_delete);
            this.Controls.Add(this.delete_vehicle);
            this.Controls.Add(this.label1);
            this.Name = "DeleteBicycle";
            this.Text = "DeleteVehicle";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button delete_vehicle;
        private System.Windows.Forms.Button cancel_delete;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.TextBox id_text_box;
        
    }
}
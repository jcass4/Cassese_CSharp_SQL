﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class InsertWorker : Form
    {
        Form myCaller;

        public InsertWorker(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string bIdVal = BannerIDTextBox.Text;
            string fNameVal = FirstNameTextBox.Text;
            string lNameVal = LastNameTextBox.Text;
            string phoneNumVal = PhoneNumberTextBox.Text;
            string emailVal = EmailTextBox.Text;
            string credVal = CredentialComboBox.Text;
            string workerPassVal = WorkerPasswordTextBox.Text;
            string notesVal = NotesTextBox.Text;

            Worker newWorker = new Worker(bIdVal, fNameVal, lNameVal, phoneNumVal, emailVal, credVal,
                                    workerPassVal, notesVal);
            newWorker.insert();
            MessageBox.Show("Worker with bannerId: " + bIdVal +
                " successfully added to database! JOHN ROCKS!!"); 
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }

        private void InsertWorker_Load(object sender, EventArgs e)
        {

        }
    }
}

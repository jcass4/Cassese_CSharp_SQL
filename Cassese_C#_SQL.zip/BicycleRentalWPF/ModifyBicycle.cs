﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ModifyBicycle : Form
    {
        Form myCaller;

        public ModifyBicycle(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            ModifyBicycleResults passForm = new ModifyBicycleResults(this);
            passForm.Passvalue = Convert.ToString(bikeIdTextBox.Text);
            passForm.Show();
            this.Hide();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}

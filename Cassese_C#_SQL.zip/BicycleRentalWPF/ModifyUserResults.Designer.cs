﻿namespace BicycleRentalWPF
{
    partial class ModifyUserResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UserTypeComboBox = new System.Windows.Forms.ComboBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.LastNameTextBox = new System.Windows.Forms.TextBox();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.NotesTextBox = new System.Windows.Forms.TextBox();
            this.EmailTextBox = new System.Windows.Forms.TextBox();
            this.FirstNameTextBox = new System.Windows.Forms.TextBox();
            this.BannerIDTextBox = new System.Windows.Forms.TextBox();
            this.NotesLabel = new System.Windows.Forms.Label();
            this.UserTypeLabel = new System.Windows.Forms.Label();
            this.EmailLabel = new System.Windows.Forms.Label();
            this.PhoneNumberLabel = new System.Windows.Forms.Label();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.BannerIDLabel = new System.Windows.Forms.Label();
            this.EnterNewUserDataLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // UserTypeComboBox
            // 
            this.UserTypeComboBox.FormattingEnabled = true;
            this.UserTypeComboBox.Items.AddRange(new object[] {
            "Faculty/Staff",
            "Student"});
            this.UserTypeComboBox.Location = new System.Drawing.Point(223, 212);
            this.UserTypeComboBox.Name = "UserTypeComboBox";
            this.UserTypeComboBox.Size = new System.Drawing.Size(99, 21);
            this.UserTypeComboBox.TabIndex = 38;
            this.UserTypeComboBox.Text = "Select One";
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(223, 284);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(99, 25);
            this.BackButton.TabIndex = 37;
            this.BackButton.Text = "BACK";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(56, 284);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(99, 25);
            this.SubmitButton.TabIndex = 36;
            this.SubmitButton.Text = "SUBMIT";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // LastNameTextBox
            // 
            this.LastNameTextBox.Location = new System.Drawing.Point(223, 128);
            this.LastNameTextBox.Name = "LastNameTextBox";
            this.LastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.LastNameTextBox.TabIndex = 35;
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(223, 157);
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.PhoneNumberTextBox.TabIndex = 34;
            // 
            // NotesTextBox
            // 
            this.NotesTextBox.Location = new System.Drawing.Point(223, 239);
            this.NotesTextBox.Name = "NotesTextBox";
            this.NotesTextBox.Size = new System.Drawing.Size(100, 20);
            this.NotesTextBox.TabIndex = 33;
            // 
            // EmailTextBox
            // 
            this.EmailTextBox.Location = new System.Drawing.Point(223, 186);
            this.EmailTextBox.Name = "EmailTextBox";
            this.EmailTextBox.Size = new System.Drawing.Size(100, 20);
            this.EmailTextBox.TabIndex = 32;
            // 
            // FirstNameTextBox
            // 
            this.FirstNameTextBox.Location = new System.Drawing.Point(223, 103);
            this.FirstNameTextBox.Name = "FirstNameTextBox";
            this.FirstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.FirstNameTextBox.TabIndex = 31;
            // 
            // BannerIDTextBox
            // 
            this.BannerIDTextBox.Location = new System.Drawing.Point(223, 77);
            this.BannerIDTextBox.Name = "BannerIDTextBox";
            this.BannerIDTextBox.Size = new System.Drawing.Size(100, 20);
            this.BannerIDTextBox.TabIndex = 30;
            // 
            // NotesLabel
            // 
            this.NotesLabel.AutoSize = true;
            this.NotesLabel.Location = new System.Drawing.Point(42, 242);
            this.NotesLabel.Name = "NotesLabel";
            this.NotesLabel.Size = new System.Drawing.Size(41, 13);
            this.NotesLabel.TabIndex = 29;
            this.NotesLabel.Text = "Notes: ";
            // 
            // UserTypeLabel
            // 
            this.UserTypeLabel.AutoSize = true;
            this.UserTypeLabel.Location = new System.Drawing.Point(42, 215);
            this.UserTypeLabel.Name = "UserTypeLabel";
            this.UserTypeLabel.Size = new System.Drawing.Size(62, 13);
            this.UserTypeLabel.TabIndex = 28;
            this.UserTypeLabel.Text = "User Type: ";
            // 
            // EmailLabel
            // 
            this.EmailLabel.AutoSize = true;
            this.EmailLabel.Location = new System.Drawing.Point(42, 189);
            this.EmailLabel.Name = "EmailLabel";
            this.EmailLabel.Size = new System.Drawing.Size(38, 13);
            this.EmailLabel.TabIndex = 27;
            this.EmailLabel.Text = "Email: ";
            // 
            // PhoneNumberLabel
            // 
            this.PhoneNumberLabel.AutoSize = true;
            this.PhoneNumberLabel.Location = new System.Drawing.Point(42, 160);
            this.PhoneNumberLabel.Name = "PhoneNumberLabel";
            this.PhoneNumberLabel.Size = new System.Drawing.Size(84, 13);
            this.PhoneNumberLabel.TabIndex = 26;
            this.PhoneNumberLabel.Text = "Phone Number: ";
            // 
            // LastNameLabel
            // 
            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.Location = new System.Drawing.Point(42, 131);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(64, 13);
            this.LastNameLabel.TabIndex = 25;
            this.LastNameLabel.Text = "Last Name: ";
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(42, 106);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(63, 13);
            this.FirstNameLabel.TabIndex = 24;
            this.FirstNameLabel.Text = "First Name: ";
            // 
            // BannerIDLabel
            // 
            this.BannerIDLabel.AutoSize = true;
            this.BannerIDLabel.Location = new System.Drawing.Point(42, 80);
            this.BannerIDLabel.Name = "BannerIDLabel";
            this.BannerIDLabel.Size = new System.Drawing.Size(61, 13);
            this.BannerIDLabel.TabIndex = 23;
            this.BannerIDLabel.Text = "Banner ID: ";
            // 
            // EnterNewUserDataLabel
            // 
            this.EnterNewUserDataLabel.AutoSize = true;
            this.EnterNewUserDataLabel.Location = new System.Drawing.Point(122, 45);
            this.EnterNewUserDataLabel.Name = "EnterNewUserDataLabel";
            this.EnterNewUserDataLabel.Size = new System.Drawing.Size(83, 13);
            this.EnterNewUserDataLabel.TabIndex = 22;
            this.EnterNewUserDataLabel.Text = "Enter User Data";
            // 
            // ModifyUserResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 355);
            this.Controls.Add(this.UserTypeComboBox);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.LastNameTextBox);
            this.Controls.Add(this.PhoneNumberTextBox);
            this.Controls.Add(this.NotesTextBox);
            this.Controls.Add(this.EmailTextBox);
            this.Controls.Add(this.FirstNameTextBox);
            this.Controls.Add(this.BannerIDTextBox);
            this.Controls.Add(this.NotesLabel);
            this.Controls.Add(this.UserTypeLabel);
            this.Controls.Add(this.EmailLabel);
            this.Controls.Add(this.PhoneNumberLabel);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.FirstNameLabel);
            this.Controls.Add(this.BannerIDLabel);
            this.Controls.Add(this.EnterNewUserDataLabel);
            this.Name = "ModifyUserResults";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ModifyUserResults_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox UserTypeComboBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.TextBox LastNameTextBox;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.TextBox NotesTextBox;
        private System.Windows.Forms.TextBox EmailTextBox;
        private System.Windows.Forms.TextBox FirstNameTextBox;
        private System.Windows.Forms.TextBox BannerIDTextBox;
        private System.Windows.Forms.Label NotesLabel;
        private System.Windows.Forms.Label UserTypeLabel;
        private System.Windows.Forms.Label EmailLabel;
        private System.Windows.Forms.Label PhoneNumberLabel;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.Label BannerIDLabel;
        private System.Windows.Forms.Label EnterNewUserDataLabel;

    }
}
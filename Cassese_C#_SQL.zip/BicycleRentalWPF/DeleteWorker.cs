﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class DeleteWorker : Form
    {
        Form myCaller;

        public DeleteWorker(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void delete_worker_Click(object sender, EventArgs e)
        {
            string bannerIDValue = banner_id_text_box.Text;
            Worker workerToDelete = new Worker();
            workerToDelete.populateWithBannerId(bannerIDValue);
            DialogResult result = MessageBox.Show("Are you sure you want to delete this worker?" +
                workerToDelete.BannerId +  "\n" + 
                workerToDelete.FirstName + "\n" + 
                workerToDelete.LastName + "\n" +
                workerToDelete.PhoneNumber + "\n" +
                workerToDelete.EmailAddress + "\n" +
                workerToDelete.Status,
                "Delete Confirm",
                MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                workerToDelete.delete();
                MessageBox.Show("You have deleted " + bannerIDValue);
            }
            else
            {
                banner_id_text_box.Text = "";
            }
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ModifyUser : Form
    {
        Form myCaller;

        public ModifyUser(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }


        private void submit_button_Click(object sender, EventArgs e)
        {
            ModifyUserResults passForm = new ModifyUserResults(this);
            passForm.Passvalue = banner_id_text_box.Text;
            passForm.Show();
            this.Hide();
        }

        private void cancel_button_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}

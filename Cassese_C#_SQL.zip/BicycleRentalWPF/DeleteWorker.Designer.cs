﻿namespace BicycleRentalWPF
{
    partial class DeleteWorker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.banner_id_text_box = new System.Windows.Forms.TextBox();
            this.delete_worker = new System.Windows.Forms.Button();
            this.cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.label1.Location = new System.Drawing.Point(107, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Delete Worker";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(61, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Banner ID";
            // 
            // banner_id_text_box
            // 
            this.banner_id_text_box.Location = new System.Drawing.Point(122, 87);
            this.banner_id_text_box.Name = "banner_id_text_box";
            this.banner_id_text_box.Size = new System.Drawing.Size(100, 20);
            this.banner_id_text_box.TabIndex = 2;
            // 
            // delete_worker
            // 
            this.delete_worker.Location = new System.Drawing.Point(81, 229);
            this.delete_worker.Name = "delete_worker";
            this.delete_worker.Size = new System.Drawing.Size(83, 38);
            this.delete_worker.TabIndex = 3;
            this.delete_worker.Text = "Delete";
            this.delete_worker.UseVisualStyleBackColor = true;
            this.delete_worker.Click += new System.EventHandler(this.delete_worker_Click);
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(170, 230);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(83, 37);
            this.cancel.TabIndex = 4;
            this.cancel.Text = "Cancel";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // DeleteWorker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(353, 328);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.delete_worker);
            this.Controls.Add(this.banner_id_text_box);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DeleteWorker";
            this.Text = "DeleteWorker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox banner_id_text_box;
        private System.Windows.Forms.Button delete_worker;
        private System.Windows.Forms.Button cancel;
    }
}
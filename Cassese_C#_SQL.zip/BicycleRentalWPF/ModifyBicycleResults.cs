﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ModifyBicycleResults : Form
    {
        Form myCaller;

        private string bikeId;

        public ModifyBicycleResults(ModifyBicycle f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }

        public string Passvalue
        {
            get { return bikeId; }
            set { bikeId = value; }
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            Vehicle veh = new Vehicle();
            veh.populate(Convert.ToInt32(bikeId));
            veh.BikeMake = BikeMakeTextBox.Text;
            veh.ModelNumber = ModelNumTextBox.Text;
            veh.SerialNumber = SerialNumTextBox.Text;
            veh.Color = ColorTextBox.Text;
            veh.Description = DescriptionTextBox.Text;
            veh.Location = LocationComboBox.Text;
            veh.PhysicalCondition = PhysicalConditionComboBox.Text;
            veh.Notes = NotesTextBox.Text;

            veh.update();
            MessageBox.Show("Bike " +bikeId+ "updated");
        }

        private void ModifyBicycleResults_Load(object sender, EventArgs e)
        {
            Vehicle vehToMod = new Vehicle();
            vehToMod.populate(Convert.ToInt32(bikeId));
            BikeMakeTextBox.Text = vehToMod.BikeMake;
            ModelNumTextBox.Text = vehToMod.ModelNumber;
            SerialNumTextBox.Text = vehToMod.SerialNumber;
            ColorTextBox.Text = vehToMod.Color;
            DescriptionTextBox.Text = vehToMod.Color;
            LocationComboBox.Text = vehToMod.Location;
            PhysicalConditionComboBox.Text = vehToMod.PhysicalCondition;
            NotesTextBox.Text = bikeId;

        }
    }
}

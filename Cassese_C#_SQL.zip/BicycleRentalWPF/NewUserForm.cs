﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class NewUserForm : Form
    {
        Form myCaller;

        public NewUserForm(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
           
            this.Hide();
            myCaller.Show();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string bIdVal = BannerIDTextBox.Text;
            string fNameVal = FirstNameTextBox.Text;
            string lNameVal = LastNameTextBox.Text;
            string phoneNumVal = PhoneNumberTextBox.Text;
            string emailVal = EmailTextBox.Text;
            string userTypeVal = UserTypeComboBox.Text;
            string notesVal = NotesTextBox.Text;

            User newUser = new User(bIdVal, fNameVal, lNameVal, phoneNumVal, emailVal, userTypeVal, 
                                    notesVal);
            newUser.insert();
            MessageBox.Show("User with bannerId: " + bIdVal +
                " successfully added to database! JOHN ROCKS!!");  
        }
    }
}
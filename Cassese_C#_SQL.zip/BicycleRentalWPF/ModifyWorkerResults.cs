﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ModifyWorkerResults : Form
    {
        Form myCaller;

        private string bannerid;

        public ModifyWorkerResults(ModifyWorker f)
        {
            InitializeComponent();
            myCaller = f;
        }

        public string Passvalue
        {
            get { return bannerid; }
            set { bannerid = value; }
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            Worker modifyWorker = new Worker();
            modifyWorker.populateWithBannerId(BannerIDTextBox.Text);
            modifyWorker.FirstName = FirstNameTextBox.Text;
            modifyWorker.LastName = LastNameTextBox.Text;
            modifyWorker.PhoneNumber = PhoneNumberTextBox.Text;
            modifyWorker.EmailAddress = EmailTextBox.Text;
            modifyWorker.WorkerPassword = WorkerPasswordTextBox.Text;
            modifyWorker.Notes = NotesTextBox.Text;

            modifyWorker.update();
            MessageBox.Show("Worker with bannerID: " + BannerIDTextBox.Text +
                " successfully edited in database!");
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }

        private void ModifyWorkerResults_Load(object sender, EventArgs e)
        {
            Worker workerToModify = new Worker();
            workerToModify.populateWithBannerId(bannerid);
            BannerIDTextBox.Text = bannerid;
            FirstNameTextBox.Text = workerToModify.FirstName;
            LastNameTextBox.Text = workerToModify.LastName;
            PhoneNumberTextBox.Text = workerToModify.PhoneNumber;
            EmailTextBox.Text = workerToModify.EmailAddress;
            WorkerPasswordTextBox.Text = workerToModify.WorkerPassword;
            NotesTextBox.Text = workerToModify.Notes;
        }
        
    }
}

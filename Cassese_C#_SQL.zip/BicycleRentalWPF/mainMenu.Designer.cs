﻿namespace BicycleRentalWPF
{
    partial class mainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rentalLabel = new System.Windows.Forms.Label();
            this.sub_label = new System.Windows.Forms.Label();
            this.user_inset = new System.Windows.Forms.Button();
            this.work_insert = new System.Windows.Forms.Button();
            this.bicycle_insert = new System.Windows.Forms.Button();
            this.user_modify = new System.Windows.Forms.Button();
            this.worker_modify = new System.Windows.Forms.Button();
            this.bicycle_modify = new System.Windows.Forms.Button();
            this.user_delete = new System.Windows.Forms.Button();
            this.worker_delete = new System.Windows.Forms.Button();
            this.bicycle_delete = new System.Windows.Forms.Button();
            this.rent_bicycle = new System.Windows.Forms.Button();
            this.return_bicycle = new System.Windows.Forms.Button();
            this.back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rentalLabel
            // 
            this.rentalLabel.AutoSize = true;
            this.rentalLabel.Location = new System.Drawing.Point(121, 20);
            this.rentalLabel.Name = "rentalLabel";
            this.rentalLabel.Size = new System.Drawing.Size(161, 13);
            this.rentalLabel.TabIndex = 0;
            this.rentalLabel.Text = "Brockport Bicycle Rental System";
            // 
            // mainMenu
            // 
            this.sub_label.AutoSize = true;
            this.sub_label.Location = new System.Drawing.Point(170, 49);
            this.sub_label.Name = "mainMenu";
            this.sub_label.Size = new System.Drawing.Size(60, 13);
            this.sub_label.TabIndex = 1;
            this.sub_label.Text = "Main Menu";
            // 
            // user_inset
            // 
            this.user_inset.Location = new System.Drawing.Point(38, 81);
            this.user_inset.Name = "user_inset";
            this.user_inset.Size = new System.Drawing.Size(104, 33);
            this.user_inset.TabIndex = 2;
            this.user_inset.Text = "Insert User";
            this.user_inset.UseVisualStyleBackColor = true;
            this.user_inset.Click += new System.EventHandler(this.user_input_Click);
            // 
            // work_insert
            // 
            this.work_insert.Location = new System.Drawing.Point(148, 81);
            this.work_insert.Name = "work_insert";
            this.work_insert.Size = new System.Drawing.Size(104, 33);
            this.work_insert.TabIndex = 3;
            this.work_insert.Text = "Insert Worker";
            this.work_insert.UseVisualStyleBackColor = true;
            this.work_insert.Click += new System.EventHandler(this.worker_insert_Click);
            // 
            // bicycle_insert
            // 
            this.bicycle_insert.Location = new System.Drawing.Point(258, 81);
            this.bicycle_insert.Name = "bicycle_insert";
            this.bicycle_insert.Size = new System.Drawing.Size(104, 33);
            this.bicycle_insert.TabIndex = 4;
            this.bicycle_insert.Text = "Insert Bicycle";
            this.bicycle_insert.UseVisualStyleBackColor = true;
            this.bicycle_insert.Click += new System.EventHandler(this.bicycle_insert_Click);
            // 
            // user_modify
            // 
            this.user_modify.Location = new System.Drawing.Point(38, 120);
            this.user_modify.Name = "user_modify";
            this.user_modify.Size = new System.Drawing.Size(104, 33);
            this.user_modify.TabIndex = 5;
            this.user_modify.Text = "Modify User";
            this.user_modify.UseVisualStyleBackColor = true;
            this.user_modify.Click += new System.EventHandler(this.user_modify_Click);
            // 
            // worker_modify
            // 
            this.worker_modify.Location = new System.Drawing.Point(148, 120);
            this.worker_modify.Name = "worker_modify";
            this.worker_modify.Size = new System.Drawing.Size(104, 33);
            this.worker_modify.TabIndex = 6;
            this.worker_modify.Text = "Modify Worker";
            this.worker_modify.UseVisualStyleBackColor = true;
            this.worker_modify.Click += new System.EventHandler(this.worker_modify_Click);
            // 
            // bicycle_modify
            // 
            this.bicycle_modify.Location = new System.Drawing.Point(258, 120);
            this.bicycle_modify.Name = "bicycle_modify";
            this.bicycle_modify.Size = new System.Drawing.Size(104, 33);
            this.bicycle_modify.TabIndex = 7;
            this.bicycle_modify.Text = "Modify Bicycle";
            this.bicycle_modify.UseVisualStyleBackColor = true;
            this.bicycle_modify.Click += new System.EventHandler(this.bicycle_modify_Click);
            // 
            // user_delete
            // 
            this.user_delete.Location = new System.Drawing.Point(38, 159);
            this.user_delete.Name = "user_delete";
            this.user_delete.Size = new System.Drawing.Size(104, 33);
            this.user_delete.TabIndex = 8;
            this.user_delete.Text = "Delete User";
            this.user_delete.UseVisualStyleBackColor = true;
            this.user_delete.Click += new System.EventHandler(this.user_delete_Click);
            // 
            // worker_delete
            // 
            this.worker_delete.Location = new System.Drawing.Point(148, 159);
            this.worker_delete.Name = "worker_delete";
            this.worker_delete.Size = new System.Drawing.Size(104, 33);
            this.worker_delete.TabIndex = 9;
            this.worker_delete.Text = "Delete Worker";
            this.worker_delete.UseVisualStyleBackColor = true;
            this.worker_delete.Click += new System.EventHandler(this.worker_delete_click);
            // 
            // bicycle_delete
            // 
            this.bicycle_delete.Location = new System.Drawing.Point(258, 159);
            this.bicycle_delete.Name = "bicycle_delete";
            this.bicycle_delete.Size = new System.Drawing.Size(104, 33);
            this.bicycle_delete.TabIndex = 10;
            this.bicycle_delete.Text = "Delete Bicycle";
            this.bicycle_delete.UseVisualStyleBackColor = true;
            this.bicycle_delete.Click += new System.EventHandler(this.bicycle_delete_Click);
            // 
            // rent_bicycle
            // 
            this.rent_bicycle.Location = new System.Drawing.Point(92, 223);
            this.rent_bicycle.Name = "rent_bicycle";
            this.rent_bicycle.Size = new System.Drawing.Size(104, 33);
            this.rent_bicycle.TabIndex = 11;
            this.rent_bicycle.Text = "Rent a Bicycle";
            this.rent_bicycle.UseVisualStyleBackColor = true;
            this.rent_bicycle.Click += new System.EventHandler(this.rent_bicycle_Click);
            // 
            // return_bicycle
            // 
            this.return_bicycle.Location = new System.Drawing.Point(202, 223);
            this.return_bicycle.Name = "return_bicycle";
            this.return_bicycle.Size = new System.Drawing.Size(104, 33);
            this.return_bicycle.TabIndex = 12;
            this.return_bicycle.Text = "Return Bicycle";
            this.return_bicycle.UseVisualStyleBackColor = true;
            this.return_bicycle.Click += new System.EventHandler(this.return_bicycle_Click);
            // 
            // back
            // 
            this.back.Location = new System.Drawing.Point(148, 262);
            this.back.Name = "back";
            this.back.Size = new System.Drawing.Size(104, 33);
            this.back.TabIndex = 13;
            this.back.Text = "Back";
            this.back.UseVisualStyleBackColor = true;
            this.back.Click += new System.EventHandler(this.back_Click);
            // 
            // sub_label
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(397, 328);
            this.Controls.Add(this.back);
            this.Controls.Add(this.return_bicycle);
            this.Controls.Add(this.rent_bicycle);
            this.Controls.Add(this.bicycle_delete);
            this.Controls.Add(this.worker_delete);
            this.Controls.Add(this.user_delete);
            this.Controls.Add(this.bicycle_modify);
            this.Controls.Add(this.worker_modify);
            this.Controls.Add(this.user_modify);
            this.Controls.Add(this.bicycle_insert);
            this.Controls.Add(this.work_insert);
            this.Controls.Add(this.user_inset);
            this.Controls.Add(this.sub_label);
            this.Controls.Add(this.rentalLabel);
            this.Name = "mainMenu";
            this.Text = "mainMenu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label rentalLabel;
        private System.Windows.Forms.Label sub_label;
        private System.Windows.Forms.Button user_inset;
        private System.Windows.Forms.Button work_insert;
        private System.Windows.Forms.Button bicycle_insert;
        private System.Windows.Forms.Button user_modify;
        private System.Windows.Forms.Button worker_modify;
        private System.Windows.Forms.Button bicycle_modify;
        private System.Windows.Forms.Button user_delete;
        private System.Windows.Forms.Button worker_delete;
        private System.Windows.Forms.Button bicycle_delete;
        private System.Windows.Forms.Button rent_bicycle;
        private System.Windows.Forms.Button return_bicycle;
        private System.Windows.Forms.Button back;
    }
}
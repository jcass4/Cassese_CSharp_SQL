﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class mainMenu : Form
    {
        MainWindow myCaller;
        Worker myLoggedinWorker;

        public mainMenu(MainWindow mw, Worker w)
        {
            InitializeComponent();
            myCaller = mw;
            myLoggedinWorker = w;
        }

        private void user_input_Click(object sender, EventArgs e)
        {
            NewUserForm inputUser = new NewUserForm(this);
            this.Hide();
            inputUser.Show();
        }

        private void worker_insert_Click(object sender, EventArgs e)
        {
            InsertWorker inputWorker = new InsertWorker(this);
            this.Hide();
            inputWorker.Show();
        }

        private void bicycle_insert_Click(object sender, EventArgs e)
        {
            InsertBicycle inputBicycle = new InsertBicycle(this);
            this.Hide();
            inputBicycle.Show();
        }

        private void user_modify_Click(object sender, EventArgs e)
        {
            ModifyUser modifyUser = new ModifyUser(this);
            this.Hide();
            modifyUser.Show();
        }

        private void worker_modify_Click(object sender, EventArgs e)
        {
            ModifyWorker modifyWorker = new ModifyWorker(this);
            this.Hide();
            modifyWorker.Show();
        }

        private void bicycle_modify_Click(object sender, EventArgs e)
        {
            ModifyBicycle modifyBicycle = new ModifyBicycle(this);
            this.Hide();
            modifyBicycle.Show();
        }

        private void user_delete_Click(object sender, EventArgs e)
        {
            DeleteUser deleteUser = new DeleteUser(this);
            this.Hide();
            deleteUser.Show();
        }

        private void worker_delete_click(object sender, EventArgs e)
        {
            DeleteWorker deleteWorker = new DeleteWorker(this);
            this.Hide();
            deleteWorker.Show();
        }

        private void bicycle_delete_Click(object sender, EventArgs e)
        {
            DeleteBicycle deleteBicycle = new DeleteBicycle(this);
            this.Hide();
            deleteBicycle.Show();
        }

        private void rent_bicycle_Click(object sender, EventArgs e)
        {
            RentBike rentABike = new RentBike(this, myLoggedinWorker);
            this.Hide();
            rentABike.Show();
        }

        private void return_bicycle_Click(object sender, EventArgs e)
        {
            ReturnBike returnABike = new ReturnBike(this, myLoggedinWorker);
            this.Hide();
            returnABike.Show();
        }

        private void back_Click(object sender, EventArgs e)
        {
         
            this.Hide();
            myCaller.Show();
        }


    }
}

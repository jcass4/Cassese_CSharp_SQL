﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class ModifyUserResults : Form
    {

        Form myCaller;

        private string bannerid;

        public ModifyUserResults(ModifyUser f)
        {
            InitializeComponent();
            myCaller = f;
        }

        public string Passvalue
        {
            get { return bannerid; }
            set { bannerid = value; }
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {

            User matt = new User();
            matt.populateWithBannerId(BannerIDTextBox.Text);
            matt.FirstName = FirstNameTextBox.Text;
            matt.LastName = LastNameTextBox.Text;
            matt.PhoneNumber = PhoneNumberTextBox.Text;
            matt.EmailAddress = EmailTextBox.Text;
            matt.UserType = UserTypeComboBox.Text;
            matt.Notes = NotesTextBox.Text;

            matt.update();
            MessageBox.Show("User with bannerId: " + BannerIDTextBox.Text +
                " successfully edited in database!");
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }

        private void ModifyUserResults_Load(object sender, EventArgs e)
        {
            User userToModify = new User();
            userToModify.populateWithBannerId(bannerid);
            BannerIDTextBox.Text = bannerid;
            FirstNameTextBox.Text = userToModify.FirstName;
            LastNameTextBox.Text = userToModify.LastName;
            PhoneNumberTextBox.Text = userToModify.PhoneNumber;
            EmailTextBox.Text = userToModify.EmailAddress;
            UserTypeComboBox.Text = userToModify.UserType;
            NotesTextBox.Text = userToModify.Notes;
        }
    }
}

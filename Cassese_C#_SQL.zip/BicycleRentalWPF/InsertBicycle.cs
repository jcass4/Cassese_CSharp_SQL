﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class InsertBicycle : Form
    {
        Form myCaller;

        public InsertBicycle(Form f)
        {
            InitializeComponent();
            myCaller = f;
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string bikeMakeVal = BikeMakeTextBox.Text;
            string modelNumVal = ModelNumTextBox.Text;
            string serialNumVal = SerialNumTextBox.Text;
            string colorVal = ColorTextBox.Text;
            string descriptionVal = DescriptionTextBox.Text;
            string locationVal = LocationComboBox.Text;
            string physicalVal = PhysicalConditionComboBox.Text;
            string notesVal = NotesTextBox.Text;

            Vehicle newVehicle = new Vehicle(bikeMakeVal, modelNumVal, serialNumVal, colorVal,
                                descriptionVal, locationVal, physicalVal, notesVal);
            newVehicle.insert();
            MessageBox.Show("Bike with Serial Number: " + modelNumVal +
               " successfully added to database!"); 
        }

        private void BackButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}

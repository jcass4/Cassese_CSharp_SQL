﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BicycleRentalWPF
{
    public partial class RentBike : Form
    {
        Form myCaller;
        Worker myLoggedInWorker;

        public RentBike(Form f, Worker w)
        {
            InitializeComponent();
            myCaller = f;
            myLoggedInWorker = w;

            VehicleCollection vc = new VehicleCollection();
            vc.populateWithGoodAndAvailableBikes();

            Object [] vehCol = vc.ToArray();
            BikeIDComboBox.Items.AddRange(vehCol);
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            string dateRented = DateTime.Now.ToString("yyyy-MM-dd");
            string timeRented = DateTime.Now.ToString("HH:mm:ss");
            string dateDue = (DateTime.Now.AddDays(3)).ToString("yyyy-MM-dd");;
            string timeDue = (DateTime.Now.AddDays(3)).ToString("HH:mm:ss");
            string dateReturned = "";
            string timeReturned = "";
            int checkoutWorkerID = myLoggedInWorker.ID;
            int checkInWorkerID = 0;

            User rentalUser = new User();
            rentalUser.populate(Convert.ToInt32(RenterIDTextBox.Text));
            int rUID = rentalUser.ID;

            Rental newRental = new Rental(rUID, Convert.ToInt32(BikeIDComboBox.Text),
                                    dateRented, timeRented, dateDue, timeDue, 
                                    dateReturned, timeReturned, checkoutWorkerID, checkInWorkerID);
            newRental.insert();
            MessageBox.Show("Bike: " + BikeIDComboBox.Text +
               " successfully rented!"); 
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            myCaller.Show();
        }
    }
}
